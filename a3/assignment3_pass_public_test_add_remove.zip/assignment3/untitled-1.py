count_up=1
count_down=2
upper_bound=5
lower_bound=0
shift=1

if (count_up+count_down)==3 and (upper_bound-lower_bound)==5*shift:
    print(" good")
    
else:
    print(" shit")
    
    
    
    
    def open_four(self, copy_board, current_color):
        second_copy_board = copy_board.copy()
        legal_moves = GoBoardUtil.generate_legal_moves_gomoku(second_copy_board)   
        the_move = None
        for i in legal_moves:
            second_copy_board.play_move_gomoku(i, current_color)
            for shift in [1,second_copy_board.NS,second_copy_board.NS+1,second_copy_board.NS-1]:
                count_up = 1
                count_down= 1
                upper_bound=0
                lower_bound=0
                p = i
                d = shift 

                while True:
                    p = p + d
                    if self.board[p] == current_color:
                        count_up = count_up + 1
                    else:
                        upper_bound=p
                        break
                d = -d
                p = i
                while True:
                    p = p + d
                    if self.board[p] == current_color:
                        count_down = count_down + 1
                    else:
                        lower_bound=p
                        break
                if (count_up+count_down)==3 and (upper_bound-lower_bound)==5*shift:
                    the_move=i
                    return True, the_move
            #clear the second_copy_board   
            second_copy_board = copy_board.copy()
                
        return False, None        
    
    
    
    
    def rule_base_simulate(self,board,color):
        copy_board = board.copy()
        current_color=color
        move=None
        
        current_result,current_move=self.direct_win(copy_board,current_color)
        if current_result:
            move=current_move
        
        opponent_color=GoBoardUtil.opponent(current_color)
        opponent_result,opponent_move=self.direct_win(copy_board,opponent_color)
        if opponent_result:
            move=opponent_move
        
        current_result,current_move=self.open_four(copy_board, current_color)
        if current_result:
            move=current_move
        
        opponent_result,opponent_move = self.open_four(copy_board, opponent_color)
        if opponent_result:
            move=opponent_move
        return move           