#!/usr/bin/python3
#/usr/local/bin/python3
# Set the path to your python3 above
import random
import gtp_connection as gtp
from gtp_connection import GtpConnection, point_to_coord
from board_util import GoBoardUtil, where1d, coord_to_point
import simple_board as sb
from simple_board import SimpleGoBoard
import numpy as np

class Gomoku():
    def __init__(self):
        """
        Gomoku player that selects moves randomly 
        from the set of legal moves.
        Passe/resigns only at the end of game.

        """
        self.name = "GomokuAssignment2"
        self.version = 1.0
        self.color = None
        self.num_of_simulate = 10
        
    def get_move(self, board, color):
        legal_moves = GoBoardUtil.generate_legal_moves_gomoku(board)
        score_lists = [0] * len(legal_moves)

        for i in range(len(legal_moves)):
            self.color = color
            score = self.simulate(board, legal_moves[i], color)
            score_lists[i] = score
    
        best_index = score_lists.index(max(score_lists))
        best_move = legal_moves[best_index]
        print(score_lists)
        
        return best_move
        
    
    def simulate(self, board, move, color):
        # index 0 = b win, index 1 = w win, index 2 = draw
        stats = [0] * 3
        winner_dic = {1:0, 2:1, 5:2}
        copy_board = board.copy()
        copy_board.play_move_gomoku(move, color)
        for i in range(self.num_of_simulate):
            self.color = GoBoardUtil.opponent(color)
            winner = self.simulate_to_end(copy_board, self.color)
            #print(str(GoBoardUtil.get_twoD_board(copy_board)))
            stats[winner_dic[winner]]+=1
        score = stats[winner_dic[color]] + stats[2]*0.5
        return score
            
        
    def simulate_to_end(self, copy_board, color):
        second_copy_board = copy_board.copy()
        legal_moves = GoBoardUtil.generate_legal_moves_gomoku(second_copy_board)
    
        is_end, winner = second_copy_board.check_game_end_gomoku()
        if is_end:
            return winner
        elif len(legal_moves) == 0:
            # 5 means draw
            return 5
        else:
            #next_move = None
            #if gtp.policy == "random":
                #next_move = GoBoardUtil.generate_random_move_gomoku(second_copy_board)
            #if gtp.policy == "rule_based":
            next_move = self.rule_base_simulate(second_copy_board)
            second_copy_board.play_move_gomoku(next_move, self.color)
            self.color = GoBoardUtil.opponent(self.color)
            
            return self.simulate_to_end(second_copy_board, self.color)
     
     
    def rule_base_simulate(self, copy_board):
        second_copy_board = copy_board.copy()
        can_direct_win, direct_win_move = self.direct_win(second_copy_board, self.color)
        if can_direct_win:
            #print(str(GoBoardUtil.get_twoD_board(second_copy_board)))
            return direct_win_move
        else:
            second_copy_board = copy_board.copy()
            can_block_direct_win, block_direct_win_move = self.direct_win(second_copy_board, GoBoardUtil.opponent(self.color))
            if can_block_direct_win:
                return block_direct_win_move
            else:
                second_copy_board = copy_board.copy()
                can_open_four, open_four_move = self.open_four(second_copy_board, self.color)
                if can_open_four:
                    return open_four_move
                else:
                    second_copy_board = copy_board.copy()
                    can_block_open_four, can_block_open_four_move = self.open_four(second_copy_board, GoBoardUtil.opponent(self.color))
                    if can_block_open_four:
                        return can_block_open_four_move
                    else:
                        second_copy_board = copy_board.copy()
                        return GoBoardUtil.generate_random_move_gomoku(second_copy_board)
    
    
    def open_four(self, copy_board, current_color, policy_moves_mode = False):
        second_copy_board = copy_board.copy()
        
        can_open_four = False
        the_move = None
        
        moved_points = second_copy_board.get_points_with_color(current_color)
        empty_points = second_copy_board.get_empty_points()
        
        #print(current_color)
        #print(str(GoBoardUtil.get_twoD_board(second_copy_board)))
        
        moved_points_2d = []
        empty_points_2d = []
        
        block_open_four_points = []
        
        for i in moved_points:
            moved_points_2d.append(point_to_coord(i, second_copy_board.size))
        for j in empty_points:
            empty_points_2d.append(point_to_coord(j, second_copy_board.size))
        
        for k in empty_points_2d:
            # right down

            if ((k[0]+5,k[1]+5) in empty_points_2d):
                possible_moves = []
                for number in range(1, 5):
                    if ((k[0]+number, k[1]+number) not in moved_points_2d):
                        possible_moves.append((k[0]+number, k[1]+number))
                if len(possible_moves) == 1:
                    if (possible_moves[0] in empty_points_2d):
                        can_open_four = True
                        the_move = possible_moves[0]
                        block_open_four_points.append(k)
                        block_open_four_points.append((k[0]+5,k[1]+5))

             # left down       
            if ((k[0]-5,k[1]+5) in empty_points_2d):
                possible_moves = []
                for number in range(1, 5):
                    if ((k[0]-number, k[1]+number) not in moved_points_2d):
                        possible_moves.append((k[0]-number, k[1]+number))
                if len(possible_moves) == 1:
                    if (possible_moves[0] in empty_points_2d):
                        can_open_four = True
                        the_move = possible_moves[0]
                        block_open_four_points.append(k)
                        block_open_four_points.append((k[0]-5,k[1]+5))                        
                        
                        
            # left
            if ((k[0]+5,k[1]) in empty_points_2d):
                possible_moves = []
                for number in range(1, 5):
                    if ((k[0]+number, k[1]) not in moved_points_2d):
                        possible_moves.append((k[0]+number, k[1]))
                if len(possible_moves) == 1:
                    if (possible_moves[0] in empty_points_2d):
                        can_open_four = True
                        the_move = possible_moves[0]
                        block_open_four_points.append(k)
                        block_open_four_points.append((k[0]+5,k[1]))                          

                
            # down
            if ((k[0],k[1]+5) in empty_points_2d):
                possible_moves = []
                for number in range(1, 5):
                    if ((k[0], k[1]+number) not in moved_points_2d):
                        possible_moves.append((k[0], k[1]+number))
                if len(possible_moves) == 1:
                    if (possible_moves[0] in empty_points_2d):
                        can_open_four = True
                        the_move = possible_moves[0]
                        block_open_four_points.append(k)
                        block_open_four_points.append((k[0],k[1]+5))  
                        
                        
        if can_open_four and policy_moves_mode == False:
            return can_open_four, coord_to_point(the_move[0], the_move[1], second_copy_board.size)
        elif can_open_four and policy_moves_mode:
            if len(block_open_four_points) > 2:
                the_move_point = []
                for i in the_move:
                    the_move_point.append(coord_to_point(i[0], i[1], second_copy_board.size))            
                return can_open_four, the_move_point
            else:
                block_open_four_points.append(the_move)
                block_open_four_points_buffer = []
                for i in block_open_four_points:
                    block_open_four_points_buffer.append(coord_to_point(i[0], i[1], second_copy_board.size))
                block_open_four_points_buffer = remove(block_open_four_points_buffer)
                return can_open_four, block_open_four_points_buffer[0]
        else:
            return False, None
                



    def direct_win(self, copy_board, current_color):
        second_copy_board = copy_board.copy()
        legal_moves = GoBoardUtil.generate_legal_moves_gomoku(second_copy_board)
        the_move = None
        for i in legal_moves:
            second_copy_board.play_move_gomoku(i, current_color)
            is_end, winner = second_copy_board.check_game_end_gomoku()
            if is_end and winner == current_color:
                the_move = i
            second_copy_board = copy_board.copy()
        if the_move != None:
            return True, the_move
        else:
            return False, None
        

                



def run():
    """
    start the gtp connection and wait for commands.
    """
    board = SimpleGoBoard(7)
    con = GtpConnection(Gomoku(), board)
    con.start_connection()

if __name__=='__main__':
    run()
